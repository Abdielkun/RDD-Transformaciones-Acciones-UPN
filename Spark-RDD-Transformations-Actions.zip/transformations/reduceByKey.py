
from pyspark import SparkContext

sc = SparkContext("local", "ReduceByKey Example")

datos = [("a", 1), ("b", 2), ("a", 3)]
rdd = sc.parallelize(datos)

# Aplicamos reduceByKey para sumar los valores con la misma clave
rdd_reduceByKey = rdd.reduceByKey(lambda x, y: x + y)
print("Resultado de reduceByKey:", rdd_reduceByKey.collect())

sc.stop()
