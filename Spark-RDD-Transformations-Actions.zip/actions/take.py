
from pyspark import SparkContext

sc = SparkContext("local", "Take Example")

datos = [("a", 1), ("b", 2), ("a", 3)]
rdd = sc.parallelize(datos)

# Acción take: Toma los primeros 2 elementos
print("Primeros 2 elementos:", rdd.take(2))

sc.stop()
