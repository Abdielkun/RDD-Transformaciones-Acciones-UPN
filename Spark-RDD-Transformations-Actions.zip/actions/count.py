
from pyspark import SparkContext

sc = SparkContext("local", "Count Example")

datos = [("a", 1), ("b", 2), ("a", 3)]
rdd = sc.parallelize(datos)

# Acción count: Cuenta el número de elementos en el RDD
print("Total de elementos:", rdd.count())

sc.stop()
