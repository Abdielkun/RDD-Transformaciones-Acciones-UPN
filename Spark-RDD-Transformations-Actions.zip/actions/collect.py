
from pyspark import SparkContext

sc = SparkContext("local", "Collect Example")

datos = [("a", 1), ("b", 2), ("a", 3)]
rdd = sc.parallelize(datos)

# Acción collect: Recupera todos los elementos del RDD
print("Todos los elementos:", rdd.collect())

sc.stop()
